### Installation

- Python 2:

      python2 -m pip install --user wheel   # only required once
      python2 setup.py bdist_wheel
      python2 -m pip install -U --user dist/lumapps_api_client-1.0.0-py2-none-any.whl

- Python 3:

      python3 -m pip install --user wheel   # only required once
      python3 setup.py bdist_wheel
      python3 -m pip install -U --user dist/lumapps_api_client-1.0.0-py3-none-any.whl

- Python 3.6

      python3.6 -m pip install --user wheel   # only required once
      python3.6 setup.py bdist_wheel
      python3.6 -m pip install -U --user dist/lumapps_api_client-1.0.0-py3-none-any.whl

### Required parameter

`--auth` JSON file that contains auth information of a service account or
web auth

- Service account (the file you download from GCP should do as-is)

        {
          "type": "service_account",
          "project_id": "gbl-imt-ve-lifepulse-dev",
          "private_key_id": ...,
          ...
        }


- Web auth

        {
          "token_uri": "https://accounts.google.com/o/oauth2/token",
          "client_id": "...",
          "client_secret": "...",
          "refresh_token": "..."
        }


- Bearer

        {
          "bearer": "Bearer F9VDFcF5YIb3dGaU="
          OR
          "bearer": "F9VDFcF5YIb3dGaU="
        }

### Optional parameter

`--api` JSON file with three parameters (example contains default values)

    {
        "base_url": "https://lumsites.appspot.com",
        "name": "lumsites",
        "version": "v1"
    }

for `drive` or `directory`, you should specify scopes

    {
        "base_url": "https://www.googleapis.com",
        "name": "admin",
        "version": "directory_v1",
        "scopes": [
            "https://www.googleapis.com/auth/admin.directory.user",
            "https://www.googleapis.com/auth/admin.directory.group",
            "https://www.googleapis.com/auth/admin.directory.group.member"
        ]
    }

`--user` The user email to use for delegation (only with service account auth)

### Usage examples

#### List API methods

    lac --auth web_auth.json

#### List methods beginning with 'comm'

    lac --auth web_auth.json comm

#### Get list of 'instances'

    lac --auth web_auth.json instance list

#### Get arguments for 'template list'

    lac --auth web_auth.json template list -h

#### Get list of 'templates'

    lac --auth web_auth.json template list instance=6724836101455872

### TODO:
- TAB completion
- Cache API discovery information
