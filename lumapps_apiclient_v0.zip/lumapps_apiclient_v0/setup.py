"""
to build on my machine:

cd ~/lumapps/lumapps-apiclient/new
python setup.py bdist_wheel

to install:
pip install -U --user dist/lumapps_api_client-1.0.0-py2-none-any.whl
"""
from setuptools import setup, find_packages
from os import path

here = path.abspath(path.dirname(__file__))
with open(path.join(here, 'README.md')) as f:
    long_description = f.read()
setup(
    name='lumapps-api-client',
    version='1.0.0',
    description='LumApps API client',
    long_description=long_description,
    url='https://github.com/lumapps/lumapps-apiclient/tree/dev/lumapps_client/new',
    author='LumApps',
    author_email='support@lumapps.com',
    license='LumApps',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.5',
    ],
    packages=find_packages(exclude=[]),
    install_requires=['google-api-python-client',
                      'google-auth',
                      'google-auth-httplib2'],
    entry_points={
        'console_scripts': [
            'lumapps_api_client=lumapps_api_client.cli:main',
            'lac=lumapps_api_client.cli:main',
        ],
    },
)